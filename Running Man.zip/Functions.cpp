#include <Allegro.h>

void increment_speed_counter()
{
	speed_counter++; 
}
END_OF_FUNCTION(increment_speed_counter);
